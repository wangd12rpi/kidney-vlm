"""Kidney VLM utilities.

Keep reusable logic here.
Runnable entrypoints live in:
- data/*.py (download, indexing, tiling)
- scripts/*.py (evaluation)
"""
